import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:screenshot/screenshot.dart';
import 'app_state.dart';
import 'widgets.dart';

class ReelScreen extends StatefulWidget {
  final VoidCallback onStateChanged;
  const ReelScreen({required this.onStateChanged});

  @override
  _ReelScreenState createState() => _ReelScreenState();
}

class _ReelScreenState extends State<ReelScreen> {
  final ScreenshotController screenshotController = ScreenshotController();

  int currentPage = 0;
  late DateTime startTime;
  Map<int, Map<String, int>> slideAnalytics = {};

  @override
  void initState() {
    super.initState();
    startTime = DateTime.now();
    slideAnalytics[0] = {"total_time": 0, "views": 1, "engaged": 0, "rewatch": 0};
  }

  @override
  void dispose() {
    final secs = DateTime.now().difference(startTime).inSeconds;
    if (slideAnalytics.containsKey(currentPage)) {
      slideAnalytics[currentPage]!["total_time"] =
          (slideAnalytics[currentPage]!["total_time"] ?? 0) + secs;
    }
    print("BACKEND FORMAT: ${getBackendData()}");
    super.dispose();
  }

  List<Map<String, dynamic>> getBackendData() {
    return slideAnalytics.entries.map((e) => {
      "slide_id": "slide_${e.key + 1}",
      "total_time": e.value["total_time"] ?? 0,
      "views": e.value["views"] ?? 0,
      "engaged": e.value["engaged"] ?? 0,
      "rewatch": e.value["rewatch"] ?? 0,
    }).toList();
  }

  void toggleLike(int index) {
    setState(() {
      if (likedSlides.contains(index)) likedSlides.remove(index);
      else likedSlides.add(index);
    });
    widget.onStateChanged();
  }

  void openSaveSheet(int index) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => SaveToFolderSheet(slideIndex: index),
    ).then((_) => setState(() {}));
  }

  void shareSlide() async {
    final idx = currentPage % topics.length;
    try {
      final image = await screenshotController.captureFromWidget(
        MediaQuery(
          data: MediaQueryData(),
          child: Directionality(
            textDirection: TextDirection.ltr,
            child: Material(
              color: Colors.transparent,
              child: Container(
                width: 380, height: 600,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF0D0D14), Color(0xFF1A1A2E)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                ),
                child: Stack(children: [
                  Container(color: Colors.black.withOpacity(0.45)),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 28, vertical: 40),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          Icon(Icons.verified_user, color: Colors.white, size: 18),
                          SizedBox(width: 6),
                          Text("EduReel", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                        ]),
                        Spacer(),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                          decoration: BoxDecoration(color: Colors.black.withOpacity(0.7), borderRadius: BorderRadius.circular(10)),
                          child: Text(topics[idx], style: TextStyle(color: Color(0xFF2563eb), fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 1.1)),
                        ),
                        SizedBox(height: 14),
                        Text(headings[idx], style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 30, height: 1.15)),
                        SizedBox(height: 12),
                        Text(descriptions[idx], style: TextStyle(color: Colors.white70, fontSize: 15, height: 1.5)),
                        SizedBox(height: 22),
                        Container(width: 80, height: 4, decoration: BoxDecoration(color: Color(0xFF2563eb), borderRadius: BorderRadius.circular(2))),
                        SizedBox(height: 20),
                        Row(children: [
                          Icon(Icons.auto_stories, color: Colors.white54, size: 16),
                          SizedBox(width: 6),
                          Text("Shared via EduReel", style: TextStyle(color: Colors.white54, fontSize: 13)),
                        ]),
                      ],
                    ),
                  ),
                ]),
              ),
            ),
          ),
        ),
        delay: Duration(milliseconds: 50),
        pixelRatio: 2.0,
      );
      await Share.shareXFiles(
        [XFile.fromData(image, name: 'slide.png', mimeType: 'image/png')],
        text: "Check this out on EduReel 👇",
      );
    } catch (_) {}
  }

  bool _isSaved(int index) =>
      savedFolders.values.any((folder) => folder.contains(index));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: PageView.builder(
          controller: globalPageController,
          scrollDirection: Axis.vertical,
          physics: const PageScrollPhysics(),
          itemCount: topics.length,
          onPageChanged: (index) {
            final secs = DateTime.now().difference(startTime).inSeconds;
            if (slideAnalytics.containsKey(currentPage)) {
              slideAnalytics[currentPage]!["total_time"] =
                  (slideAnalytics[currentPage]!["total_time"] ?? 0) + secs;
              if (secs > 1)
                slideAnalytics[currentPage]!["engaged"] =
                    (slideAnalytics[currentPage]!["engaged"] ?? 0) + 1;
            }
            currentPage = index % topics.length;
            startTime = DateTime.now();
            if (slideAnalytics.containsKey(currentPage)) {
              final v = (slideAnalytics[currentPage]!["views"] ?? 0) + 1;
              slideAnalytics[currentPage]!["views"] = v;
              if (v > 1)
                slideAnalytics[currentPage]!["rewatch"] =
                    (slideAnalytics[currentPage]!["rewatch"] ?? 0) + 1;
            } else {
              slideAnalytics[currentPage] = {"total_time": 0, "views": 1, "engaged": 0, "rewatch": 0};
            }
            print("BACKEND FORMAT: ${getBackendData()}");
          },
          itemBuilder: (context, index) {
            final realIndex = index % topics.length;
            final isLiked = likedSlides.contains(realIndex);
            final saved = _isSaved(realIndex);

            return GestureDetector(
              onDoubleTap: () => toggleLike(realIndex),
              child: Stack(children: [
                // Background gradient
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF0D0D14), Color(0xFF1A1A2E)],
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                    ),
                  ),
                ),
                Container(color: Colors.black.withOpacity(0.35)),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 32),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ── Content ──────────────────────────────────────────
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(children: [
                              Icon(Icons.verified_user, color: Colors.white, size: 18),
                              SizedBox(width: 6),
                              Text("For You", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                              Spacer(),
                              Icon(Icons.search, color: Colors.white, size: 20),
                            ]),
                            Spacer(),
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.7),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(topics[realIndex],
                                  style: TextStyle(color: Color(0xFF2563eb), fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 1.1)),
                            ),
                            SizedBox(height: 12),
                            Text(headings[realIndex],
                                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 28, height: 1.1)),
                            SizedBox(height: 10),
                            Text(descriptions[realIndex],
                                style: TextStyle(color: Colors.white70, fontSize: 14)),
                            SizedBox(height: 18),
                            Container(
                              width: 80, height: 4,
                              decoration: BoxDecoration(color: Color(0xFF2563eb), borderRadius: BorderRadius.circular(2)),
                            ),
                          ],
                        ),
                      ),

                      // ── Action buttons ────────────────────────────────────
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // ❤️ Like
                          GestureDetector(
                            onTap: () => toggleLike(realIndex),
                            child: Column(children: [
                              AnimatedSwitcher(
                                duration: Duration(milliseconds: 200),
                                transitionBuilder: (child, anim) => ScaleTransition(scale: anim, child: child),
                                child: Icon(
                                  isLiked ? Icons.favorite : Icons.favorite_border,
                                  key: ValueKey(isLiked),
                                  color: isLiked ? Colors.redAccent : Colors.white,
                                  size: 32,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(isLiked ? "Liked" : "Like",
                                  style: TextStyle(color: isLiked ? Colors.redAccent : Colors.white70, fontSize: 11)),
                            ]),
                          ),
                          SizedBox(height: 20),

                          // 🔖 Bookmark
                          GestureDetector(
                            onTap: () => openSaveSheet(realIndex),
                            child: Column(children: [
                              AnimatedSwitcher(
                                duration: Duration(milliseconds: 200),
                                transitionBuilder: (child, anim) => ScaleTransition(scale: anim, child: child),
                                child: Icon(
                                  saved ? Icons.bookmark : Icons.bookmark_border,
                                  key: ValueKey(saved),
                                  color: saved ? Color(0xFF2563eb) : Colors.white,
                                  size: 32,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(saved ? "Saved" : "Save",
                                  style: TextStyle(color: saved ? Color(0xFF2563eb) : Colors.white70, fontSize: 11)),
                            ]),
                          ),
                          SizedBox(height: 20),

                          // 📤 Share
                          GestureDetector(
                            onTap: shareSlide,
                            child: Column(children: [
                              Icon(Icons.share, color: Colors.white, size: 32),
                              SizedBox(height: 4),
                              Text("Share", style: TextStyle(color: Colors.white70, fontSize: 11)),
                            ]),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ]),
            );
          },
        ),
      ),
    );
  }
}
