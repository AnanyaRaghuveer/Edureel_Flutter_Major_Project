import 'package:flutter/material.dart';
import 'app_state.dart';
import 'pages.dart';

class DashboardScreen extends StatefulWidget {
  final VoidCallback onNavigateToFeed;
  const DashboardScreen({required this.onNavigateToFeed});

  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  void _onMenuSelected(String value) {
    Widget page;
    if (value == 'profile') page = ProfilePage();
    else if (value == 'liked') page = LikedVideosPage();
    else page = SavedVideosPage();
    Navigator.push(context, MaterialPageRoute(builder: (_) => page))
        .then((_) => setState(() {}));
  }

  void _navigateToSlide(int index) {
    jumpToSlide(index);
    widget.onNavigateToFeed();
  }

  @override
  Widget build(BuildContext context) {
    final totalSaved = savedFolders.values.fold<int>(0, (s, v) => s + v.length);

    return Scaffold(
      backgroundColor: Color(0xFF111214),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Top Bar ─────────────────────────────────────────────────
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Dashboard",
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 22)),
                  PopupMenuButton<String>(
                    onSelected: _onMenuSelected,
                    color: Color(0xFF1E1F24),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                      side: BorderSide(color: Colors.white12),
                    ),
                    offset: Offset(0, 52),
                    child: CircleAvatar(
                      radius: 20,
                      backgroundColor: Color(0xFF2563eb),
                      child: Icon(Icons.person, color: Colors.black, size: 22),
                    ),
                    itemBuilder: (context) => [
                      _menuItem('profile', Icons.person_outline, 'Profile'),
                      _menuItem('liked', Icons.favorite_border, 'Liked Videos'),
                      _menuItem('saved', Icons.bookmark_border, 'Saved Videos'),
                    ],
                  ),
                ],
              ),
              SizedBox(height: 28),

              // ── Heading ──────────────────────────────────────────────────
              Text("Learning Progress",
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 28,
                      letterSpacing: -1.2)),
              SizedBox(height: 4),
              Text("Your daily knowledge intake at a glance.",
                  style: TextStyle(color: Colors.white70, fontSize: 14)),
              SizedBox(height: 24),

              // ── Stats Grid ───────────────────────────────────────────────
              Row(children: [
                _StatCard(
                  icon: Icons.favorite,
                  iconColor: Colors.redAccent,
                  label: "Liked",
                  value: "${likedSlides.length}",
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LikedVideosPage())).then((_) => setState(() {})),
                ),
                SizedBox(width: 12),
                _StatCard(
                  icon: Icons.bookmark,
                  iconColor: Color(0xFF2563eb),
                  label: "Saved",
                  value: "$totalSaved",
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SavedVideosPage())).then((_) => setState(() {})),
                ),
              ]),
              SizedBox(height: 12),
              Row(children: [
                _StatCard(
                  icon: Icons.folder,
                  iconColor: Color(0xFFFFB74D),
                  label: "Folders",
                  value: "${savedFolders.length}",
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SavedVideosPage())).then((_) => setState(() {})),
                ),
                SizedBox(width: 12),
                _StatCard(
                  icon: Icons.auto_stories,
                  iconColor: Color(0xFF9C7CFF),
                  label: "Topics",
                  value: "${topics.length}",
                ),
              ]),
              SizedBox(height: 24),

              // ── Deep Focus Card ──────────────────────────────────────────
              _InfoCard(
                gradient: LinearGradient(
                  colors: [Color(0xFF1A2744), Color(0xFF232B2E)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                ),
                child: Row(children: [
                  _IconBubble(Icons.psychology, Color(0xFF2563eb)),
                  SizedBox(width: 16),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text("Deep Focus", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                    Text("Keep going — you're on a streak!", style: TextStyle(color: Colors.white54, fontSize: 13)),
                  ])),
                  Icon(Icons.local_fire_department, color: Colors.orangeAccent, size: 28),
                ]),
              ),
              SizedBox(height: 12),

              // ── Accuracy Card ────────────────────────────────────────────
              _InfoCard(
                color: Color(0xFF18191C),
                child: Row(children: [
                  _IconBubble(Icons.track_changes, Color(0xFF2563eb)),
                  SizedBox(width: 16),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text("Accuracy", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                    Text("Engage with slides for better recall.", style: TextStyle(color: Colors.white54, fontSize: 13)),
                  ])),
                  Text("--", style: TextStyle(color: Color(0xFF2563eb), fontWeight: FontWeight.bold, fontSize: 22)),
                ]),
              ),
              SizedBox(height: 12),

              // ── Completed & Streak ───────────────────────────────────────
              Row(children: [
                Expanded(child: _InfoCard(
                  color: Color(0xFF18191C),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Icon(Icons.check_circle_outline, color: Color(0xFF2563eb), size: 24),
                    SizedBox(height: 8),
                    Text("${likedSlides.length}", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 24)),
                    Text("Completed", style: TextStyle(color: Colors.white54, fontSize: 12)),
                  ]),
                )),
                SizedBox(width: 12),
                Expanded(child: _InfoCard(
                  color: Color(0xFF18191C),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Icon(Icons.local_fire_department, color: Colors.orangeAccent, size: 24),
                    SizedBox(height: 8),
                    Text("0", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 24)),
                    Text("Day Streak", style: TextStyle(color: Colors.white54, fontSize: 12)),
                  ]),
                )),
              ]),
              SizedBox(height: 12),

              // ── Weekly Activity ──────────────────────────────────────────
              _InfoCard(
                color: Color(0xFF18191C),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text("Weekly Activity",
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                  SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: List.generate(7, (i) {
                      final days = ["M", "T", "W", "T", "F", "S", "S"];
                      final h = [0.4, 0.7, 0.5, 0.9, 0.3, 0.6, 0.2];
                      return Column(children: [
                        Container(
                          width: 10, height: 60 * h[i],
                          decoration: BoxDecoration(
                            color: Color(0xFF2563eb).withOpacity(0.5 + h[i] * 0.5),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                        SizedBox(height: 6),
                        Text(days[i], style: TextStyle(color: Colors.white38, fontSize: 11)),
                      ]);
                    }),
                  ),
                ]),
              ),
              SizedBox(height: 24),

              // ── Continue Learning ────────────────────────────────────────
              Text("Continue Learning",
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
              SizedBox(height: 12),
              ...List.generate(topics.length, (i) => _ContinueCard(
                index: i,
                onTap: () => _navigateToSlide(i),
              )),
              SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  PopupMenuItem<String> _menuItem(String value, IconData icon, String label) {
    return PopupMenuItem<String>(
      value: value,
      child: Row(children: [
        Icon(icon, color: Colors.white70, size: 18),
        SizedBox(width: 12),
        Text(label, style: TextStyle(color: Colors.white, fontSize: 14)),
      ]),
    );
  }
}

// ── Small helpers ─────────────────────────────────────────────────────────────
class _StatCard extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String label, value;
  final VoidCallback? onTap;
  const _StatCard({required this.icon, required this.iconColor, required this.label, required this.value, this.onTap});

  @override
  Widget build(BuildContext context) => Expanded(
    child: GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(color: Color(0xFF18191C), borderRadius: BorderRadius.circular(16)),
        child: Row(children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(color: iconColor.withOpacity(0.15), shape: BoxShape.circle),
            child: Icon(icon, color: iconColor, size: 18),
          ),
          SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(value, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20)),
            Text(label, style: TextStyle(color: Colors.white54, fontSize: 11)),
          ]),
        ]),
      ),
    ),
  );
}

class _InfoCard extends StatelessWidget {
  final Widget child;
  final Color? color;
  final LinearGradient? gradient;
  const _InfoCard({required this.child, this.color, this.gradient});

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: color, gradient: gradient,
      borderRadius: BorderRadius.circular(18),
    ),
    child: child,
  );
}

class _IconBubble extends StatelessWidget {
  final IconData icon;
  final Color color;
  const _IconBubble(this.icon, this.color);

  @override
  Widget build(BuildContext context) => Container(
    padding: EdgeInsets.all(12),
    decoration: BoxDecoration(color: color.withOpacity(0.2), shape: BoxShape.circle),
    child: Icon(icon, color: color, size: 24),
  );
}

class _ContinueCard extends StatelessWidget {
  final int index;
  final VoidCallback onTap;
  const _ContinueCard({required this.index, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      margin: EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [Color(0xFF1A2230), Color(0xFF18191C)],
            begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(children: [
        Container(
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(color: Color(0xFF2563eb).withOpacity(0.15), shape: BoxShape.circle),
          child: Icon(Icons.play_circle_filled, color: Color(0xFF2563eb), size: 22),
        ),
        SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(headings[index],
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
              maxLines: 1, overflow: TextOverflow.ellipsis),
          Text(topics[index], style: TextStyle(color: Color(0xFF2563eb), fontSize: 11)),
        ])),
        Icon(Icons.arrow_forward_ios, color: Colors.white24, size: 16),
      ]),
    ),
  );
}
